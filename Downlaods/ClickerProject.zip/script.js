var score = 0;
var clickingpower = 1;

var basicmotherboardcost = 15;
var basicmotherboards = 0;
var gbRAMcost = 100;
var gbRAMs = 0;
var GPUcost = 1000;
var GPUs = 0;
var SSDcost = 10000;
var SSDs = 0;
var CPUcost = 50000;
var CPUs = 0;

var normalmotherboardcost = 100000;
var normalmotherboards = 0;
var normalRAMcost = 500000;
var normalRAMs = 0;
var normalGPUcost = 1000000;
var normalGPUs = 0;
var normalSSDcost = 2500000;
var normalSSDs = 0;
var normalCPUcost = 5000000;
var normalCPUs = 0;

var advancedmotherboardcost = 10000000;
var advancedmotherboards = 0;
var advancedRAMcost = 25000000;
var advancedRAMs = 0;
var advancedGPUcost = 50000000;
var advancedGPUs = 0;
var advancedSSDcost = 75000000;
var advancedSSDs = 0;
var advancedCPUcost = 100000000;
var advancedCPUs = 0;

var Promotherboardcost = 250000000;
var Promotherboards = 0;
var ProRAMcost = 500000000;
var ProRAMs = 0;
var ProGPUcost = 750000000;
var ProGPUs = 0;
var ProSSDcost = 1000000000;
var ProSSDs = 0;
var ProCPUcost = 1250000000;
var ProCPUs = 0;

var opmotherboardcost = 1750000000;
var opmotherboards = 0;
var opRAMcost = 2500000000;
var opRAMs = 0;
var opGPUcost = 3000000000;
var opGPUs = 0;
var opSSDcost = 3750000000;
var opSSDs = 0;
var opCPUcost = 4000000000;
var opCPUs = 0;

var amotherboardcost = 5000000000;
var amotherboards = 0;
var aRAMcost = 7500000000;
var aRAMs = 0;
var aGPUcost = 8500000000
var aGPUs = 0;
var aSSDcost = 10000000000;
var aSSDs = 0;
var aCPUcost = 15000000000;
var aCPUs = 0;


function buybasicmotherboard() {
if (score >= basicmotherboardcost) {
score = score - basicmotherboardcost;
basicmotherboards = basicmotherboards + 1; 
basicmotherboardcost = Math.round(basicmotherboardcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("basicmotherboardcost").innerHTML = basicmotherboardcost;
document.getElementById("basicmotherboards").innerHTML = basicmotherboards;
updatescorepersecond();
}
}


function buygbRAM() {
if (score >= gbRAMcost) {
score = score - gbRAMcost;
gbRAMs = gbRAMs + 1; 
gbRAMcost = Math.round(gbRAMcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("gbRAMcost").innerHTML = gbRAMcost;
document.getElementById("gbRAMs").innerHTML = gbRAMs;
updatescorepersecond();
}
}

function buyGPU() {
if (score >= GPUcost) {
score = score - GPUcost;
GPUs = GPUs + 1; 
GPUcost = Math.round(GPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("GPUcost").innerHTML = GPUcost;
document.getElementById("GPUs").innerHTML = GPUs;
updatescorepersecond();
}
}

function buySSD() {
if (score >= SSDcost) {
score = score - SSDcost;
SSDs = SSDs + 1; 
SSDcost = Math.round(SSDcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("SSDcost").innerHTML = SSDcost;
document.getElementById("SSDs").innerHTML = SSDs;
updatescorepersecond();
}
}

function buyCPU() {
if (score >= CPUcost) {
score = score - CPUcost;
CPUs = CPUs + 1;
CPUcost = Math.round(CPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("CPUcost").innerHTML = CPUcost;
document.getElementById("CPUs").innerHTML = CPUs;
updatescorepersecond();
}
}

function buynormalmotherboard() {
if (score >= normalmotherboardcost) {
score = score - normalmotherboardcost;
normalmotherboards = normalmotherboards + 1; 
normalmotherboardcost = Math.round(normalmotherboardcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("normalmotherboardcost").innerHTML = normalmotherboardcost;
document.getElementById("normalmotherboards").innerHTML = normalmotherboards;
updatescorepersecond();
}
}

function buynormalRAM() {
if (score >= normalRAMcost) {
score = score - normalRAMcost;
normalRAMs = normalRAMs + 1; 
normalRAMcost = Math.round(normalRAMcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("normalRAMcost").innerHTML = normalRAMcost;
document.getElementById("normalRAMs").innerHTML = normalRAMs;
updatescorepersecond();
}
}

function buynormalGPU() {
if (score >= normalGPUcost) {
score = score - normalGPUcost;
normalGPUs = normalGPUs + 1; 
normalGPUcost = Math.round(normalGPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("normalGPUcost").innerHTML = normalGPUcost;
document.getElementById("normalGPUs").innerHTML = normalGPUs;
updatescorepersecond();
}
}

function buynormalSSD() {
if (score >= normalSSDcost) {
score = score - normalSSDcost;
normalSSDs = normalSSDs + 1; 
normalSSDcost = Math.round(normalSSDcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("normalSSDcost").innerHTML = normalSSDcost;
document.getElementById("normalSSDs").innerHTML = normalSSDs;
updatescorepersecond();
}
}

function buynormalCPU() {
if (score >= normalCPUcost) {
score = score - normalCPUcost;
normalCPUs = normalCPUs + 1;
normalCPUcost = Math.round(normalCPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("normalCPUcost").innerHTML = normalCPUcost;
document.getElementById("normalCPUs").innerHTML = normalCPUs;
updatescorepersecond();
}
}

function buyadvancedmotherboard() {
if (score >= advancedmotherboardcost) {
score = score - advancedmotherboardcost;
advancedmotherboards = advancedmotherboards + 1; 
advancedmotherboardcost = Math.round(advancedmotherboardcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("advancedmotherboardcost").innerHTML = advancedmotherboardcost;
document.getElementById("advancedmotherboards").innerHTML = advancedmotherboards;
updatescorepersecond();
}
}

function buyadvancedRAM() {
if (score >= advancedRAMcost) {
score = score - advancedRAMcost;
advancedRAMs = advancedRAMs + 1; 
advancedRAMcost = Math.round(advancedRAMcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("advancedRAMcost").innerHTML = advancedRAMcost;
document.getElementById("advancedRAMs").innerHTML = advancedRAMs;
updatescorepersecond();
}
}

function buyadvancedGPU() {
if (score >= advancedGPUcost) {
score = score - advancedGPUcost;
advancedGPUs = advancedGPUs + 1; 
advancedGPUcost = Math.round(advancedGPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("advancedGPUcost").innerHTML = advancedGPUcost;
document.getElementById("advancedGPUs").innerHTML = advancedGPUs;
updatescorepersecond();
}
}

function buyadvancedSSD() {
if (score >= advancedSSDcost) {
score = score - advancedSSDcost;
advancedSSDs = advancedSSDs + 1; 
advancedSSDcost = Math.round(advancedSSDcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("advancedSSDcost").innerHTML = advancedSSDcost;
document.getElementById("advancedSSDs").innerHTML = advancedSSDs;
updatescorepersecond();
}
}

function buyadvancedCPU() {

if (score >= advancedCPUcost) {
score = score - advancedCPUcost;
advancedCPUs = advancedCPUs + 1;
advancedCPUcost = Math.round(advancedCPUcost * 1.15);

document.getElementById("score").innerHTML = score;
document.getElementById("advancedCPUcost").innerHTML = advancedCPUcost;
document.getElementById("advancedCPUs").innerHTML = advancedCPUs;
updatescorepersecond();
}
}

function buypromotherboard() {

if (score >= Promotherboardcost) {
score = score - Promotherboardcost;
Promotherboards = Promotherboards + 1; 
Promotherboardcost = Math.round(Promotherboardcost * 1.225);

document.getElementById("score").innerHTML = score;
document.getElementById("Promotherboardcost").innerHTML = Promotherboardcost;
document.getElementById("Promotherboards").innerHTML = Promotherboards;
updatescorepersecond();
}
}

function buyproRAM() {
if (score >= ProRAMcost) {
score = score - ProRAMcost;
ProRAMs = ProRAMs + 1; 
ProRAMcost = Math.round(ProRAMcost * 1.255);

document.getElementById("score").innerHTML = score;
document.getElementById("ProRAMcost").innerHTML = ProRAMcost;
document.getElementById("ProRAMs").innerHTML = ProRAMs;
updatescorepersecond();
}
}

function buyproGPU() {
if (score >= ProGPUcost) {
score = score - ProGPUcost;
ProGPUs = ProGPUs + 1; 
ProGPUcost = Math.round(ProGPUcost * 1.255);

document.getElementById("score").innerHTML = score;
document.getElementById("ProGPUcost").innerHTML = ProGPUcost;
document.getElementById("ProGPUs").innerHTML = ProGPUs;
updatescorepersecond();
}
}

function buyproSSD() {
if (score >= ProSSDcost) {
score = score - ProSSDcost;
ProSSDs = ProSSDs + 1; 
ProSSDcost = Math.round(ProSSDcost * 1.255);

document.getElementById("score").innerHTML = score;
document.getElementById("ProSSDcost").innerHTML = ProSSDcost;
document.getElementById("ProSSDs").innerHTML = ProSSDs;
updatescorepersecond();
}
}

function buyproCPU() {

if (score >= ProCPUcost) {
score = score - ProCPUcost;
ProCPUs = ProCPUs + 1;
ProCPUcost = Math.round(ProCPUcost * 1.255);

document.getElementById("score").innerHTML = score;
document.getElementById("ProCPUcost").innerHTML = ProCPUcost;
document.getElementById("ProCPUs").innerHTML = ProCPUs;
updatescorepersecond();
}
}

function buyopmotherboard() {

if (score >= opmotherboardcost) {
score = score - opmotherboardcost;
opmotherboards = opmotherboards + 1; 
opmotherboardcost = Math.round(opmotherboardcost * 1.75);

document.getElementById("score").innerHTML = score;
document.getElementById("opmotherboardcost").innerHTML = opmotherboardcost;
document.getElementById("opmotherboards").innerHTML = opmotherboards;
updatescorepersecond();
}
}

function buyopRAM() {
if (score >= opRAMcost) {
score = score - opRAMcost;
opRAMs = opRAMs + 1; 
opRAMcost = Math.round(opRAMcost * 1.75);

document.getElementById("score").innerHTML = score;
document.getElementById("opRAMcost").innerHTML = opRAMcost;
document.getElementById("opRAMs").innerHTML = opRAMs;
updatescorepersecond();
}
}

function buyopGPU() {
if (score >= opGPUcost) {
score = score - opGPUcost;
opGPUs = opGPUs + 1; 
opGPUcost = Math.round(opGPUcost * 1.75);

document.getElementById("score").innerHTML = score;
document.getElementById("opGPUcost").innerHTML = opGPUcost;
document.getElementById("opGPUs").innerHTML = opGPUs;
updatescorepersecond();
}
}

function buyopSSD() {
if (score >= opSSDcost) {
score = score - opSSDcost;
opSSDs = opSSDs + 1; 
opSSDcost = Math.round(opSSDcost * 1.75);

document.getElementById("score").innerHTML = score;
document.getElementById("opSSDcost").innerHTML = opSSDcost;
document.getElementById("opSSDs").innerHTML = opSSDs;
updatescorepersecond();
}
}

function buyopCPU() {
if (score >= opCPUcost) {
score = score - opCPUcost;
opCPUs = opCPUs + 1;
opCPUcost = Math.round(opCPUcost * 1.75);

document.getElementById("score").innerHTML = score;
document.getElementById("opCPUcost").innerHTML = opCPUcost;
document.getElementById("opCPUs").innerHTML = opCPUs;
updatescorepersecond();
}
}

function buyamotherboard() {
if (score >= amotherboardcost) {
score = score - amotherboardcost;
amotherboards = amotherboards + 1; 
amotherboardcost = Math.round(amotherboardcost * 2.15);

document.getElementById("score").innerHTML = score;
document.getElementById("amotherboardcost").innerHTML = amotherboardcost;
document.getElementById("amotherboards").innerHTML = amotherboards;
updatescorepersecond();
}
}

function buyaRAM () {
if (score >= aRAMcost) {
score = score - aRAMcost;
aRAMs = aRAMs + 1; 
aRAMcost = Math.round(aRAMcost * 2.15);

document.getElementById("score").innerHTML = score;
document.getElementById("aRAMcost").innerHTML = aRAMcost;
document.getElementById("aRAMs").innerHTML = aRAMs;
updatescorepersecond();
}
}

function buyaGPU () {
if (score >= aGPUcost) {
score = score - aGPUcost;
aGPUs = aGPUs + 1; 
aGPUcost = Math.round(aGPUcost * 2.15);

document.getElementById("score").innerHTML = score;
document.getElementById("aGPUcost").innerHTML = aGPUcost;
document.getElementById("aGPUs").innerHTML = aGPUs;
updatescorepersecond();
}
}

function buyaSSD () {
if (score >= aSSDcost) {
score = score - aSSDcost;
aSSDs = aSSDs + 1; 
aSSDcost = Math.round(aSSDcost * 2.15);

document.getElementById("score").innerHTML = score;
document.getElementById("aSSDcost").innerHTML = aSSDcost;
document.getElementById("aSSDs").innerHTML = aSSDs;
updatescorepersecond();
}
}

function buyaCPU () {
if (score >= aCPUcost) {
score = score - aCPUcost;
aCPUs = aCPUs + 1; 
aCPUcost = Math.round(aCPUcost * 2.15);

document.getElementById("score").innerHTML = score;
document.getElementById("aCPUcost").innerHTML = aCPUcost;
document.getElementById("aCPUs").innerHTML = aCPUs;
updatescorepersecond();
}
}

function resetGame() {
if (confirm("are you sure you want to reset your game")) {
var gamesave = {};
localStorage.setItem("gamesave", JSON.stringify(gamesave));
location.reload();
}
}

function addtoscore(amount) {
score = score + amount;
document.getElementById("score").innerHTML = score;
document.getElementById("score").innerHTML = score;
}

function loadgame() {
var savedgame = JSON.parse(localStorage.getItem("gamesave"));

if (typeof savedgame.score !== "undefined") score = savedgame.score;
if (typeof savedgame.clickingpower !== "undefined") clickingpower = savedgame.clickingpower;
if (typeof savedgame.basicmotherboardcost !== "undefined") basicmotherboardcost = savedgame.basicmotherboardcost;
if (typeof savedgame.basicmotherboards !== "undefined") basicmotherboards = savedgame.basicmotherboards;
if (typeof savedgame.gbRAMcost !== "undefined") gbRAMcost = savedgame.gbRAMcost;
if (typeof savedgame.gbRAMs !== "undefined") gbRAMs = savedgame.gbRAMs;
if (typeof savedgame.GPUcost !== "undefined") GPUcost = savedgame.GPUcost;
if (typeof savedgame.GPUs !== "undefined") GPUs = savedgame.GPUs;
if (typeof savedgame.SSDcost !== "undefined") SSDcost = savedgame.SSDcost;
if (typeof savedgame.SSDs !== "undefined") SSDs = savedgame.SSDs;
if (typeof savedgame.CPUcost !== "undefined") CPUcost = savedgame.CPUcost;
if (typeof savedgame.CPUs !== "undefined") CPUs = savedgame.CPUs;

if (typeof savedgame.normalmotherboardcost !== "undefined") normalmotherboardcost = savedgame.normalmotherboardcost;
if (typeof savedgame.normalmotherboards !== "undefined") normalmotherboards = savedgame.normalmotherboards;
if (typeof savedgame.normalRAMcost !== "undefined") normalRAMcost = savedgame.normalRAMcost;
if (typeof savedgame.normalRAMs!== "undefined") normalRAMs = savedgame.normalRAMs;
if (typeof savedgame.normalGPUcost !== "undefined") normalGPUcost = savedgame.normalGPUcost;
if (typeof savedgame.normalGPUs !== "undefined") normalGPUs = savedgame.normalGPUs;
if (typeof savedgame.normalSSDcost !== "undefined") normalSSDcost = savedgame.normalSSDcost;
if (typeof savedgame.normalSSDs !== "undefined") normalSSDs = savedgame.normalSSDs;
if (typeof savedgame.normalCPUcost !== "undefined") normalCPUcost = savedgame.normalCPUcost;
if (typeof savedgame.normalCPUs !== "undefined") normalCPUs = savedgame.normalCPUs;

if (typeof savedgame.advancedmotherboardcost !== "undefined") advancedmotherboardcost = savedgame.advancedmotherboardcost;
if (typeof savedgame.advancedmotherboards !== "undefined") advancedmotherboards = savedgame.advancedmotherboards;
if (typeof savedgame.advancedRAMcost !== "undefined") advancedRAMcost = savedgame.advancedRAMcost;
if (typeof savedgame.advancedRAMs !== "undefined") advancedRAMs = savedgame.advancedRAMs;
if (typeof savedgame.advancedGPUcost !== "undefined") advancedGPUcost = savedgame.advancedGPUcost;
if (typeof savedgame.advancedGPUs !== "undefined") advancedGPUs = savedgame.advancedGPUs;
if (typeof savedgame.advancedSSDcost !== "undefined") advancedSSDcost = savedgame.advancedSSDcost;
if (typeof savedgame.advancedSSDs !== "undefined") advancedSSDs = savedgame.advancedSSDs;
if (typeof savedgame.advancedCPUcost !== "undefined") advancedCPUcost = savedgame.advancedCPUcost;
if (typeof savedgame.advancedCPUs !== "undefined") advancedCPUs = savedgame.advancedCPUs;

if (typeof savedgame.Promotherboardcost !== "undefined") Promotherboardcost = savedgame.Promotherboardcost;
if (typeof savedgame.Promotherboards !== "undefined") Promotherboards = savedgame.Promotherboards;
if (typeof savedgame.ProRAMcost !== "undefined") ProRAMcost = savedgame.ProRAMcost;
if (typeof savedgame.ProRAMs !== "undefined") ProRAMs = savedgame.ProRAMs;
if (typeof savedgame.ProGPUcost !== "undefined") ProGPUcost = savedgame.ProGPUcost;
if (typeof savedgame.ProGPUs !== "undefined") ProGPUs = savedgame.ProGPUs;
if (typeof savedgame.ProSSDcost !== "undefined") ProSSDcost = savedgame.ProSSDcost;
if (typeof savedgame.ProSSDs !== "undefined") ProSSDs = savedgame.ProSSDs;
if (typeof savedgame.ProCPUcost !== "undefined") ProCPUcost = savedgame.ProCPUcost;
if (typeof savedgame.ProCPUs !== "undefined") ProCPUs = savedgame.ProCPUs;

if (typeof savedgame.opmotherboardcost !== "undefined") opmotherboardcost = savedgame.opmotherboardcost;
if (typeof savedgame.opmotherboards !== "undefined") opmotherboards = savedgame.opmotherboards;
if (typeof savedgame.opRAMcost !== "undefined") opRAMcost = savedgame.opRAMcost;
if (typeof savedgame.opRAMs !== "undefined") opRAMs = savedgame.opRAMs;
if (typeof savedgame.opGPUcost !== "undefined") opGPUcost = savedgame.opGPUcost;
if (typeof savedgame.opGPUs !== "undefined") opGPUs = savedgame.opGPUs;
if (typeof savedgame.opSSDcost !== "undefined") opSSDcost = savedgame.opSSDcost;
if (typeof savedgame.opSSDs !== "undefined") opSSDs = savedgame.opSSDs;
if (typeof savedgame.opCPUcost !== "undefined") opCPUcost = savedgame.opCPUcost;
if (typeof savedgame.opCPUs !== "undefined") opCPUs = savedgame.opCPUs;

if (typeof savedgame.amotherboardcost !== "undefined") amotherboardcost = savedgame.amotherboardcost;
if (typeof savedgame.amotherboards !== "undefined") amotherboards = savedgame.amotherboards;
if (typeof savedgame.aRAMcost !== "undefined") aRAMcost = savedgame.aRAMcost;
if (typeof savedgame.aRAMs !== "undefined") aRAMs = savedgame.aRAMs;
if (typeof savedgame.aGPUcost !== "undefined") aGPUcost = savedgame.aGPUcost;
if (typeof savedgame.aGPUs !== "undefined") aGPUs = savedgame.aGPUs;
if (typeof savedgame.aSSDcost !== "undefined") aSSDcost = savedgame.aSSDcost;
if (typeof savedgame.aSSDs !== "undefined") aSSDs = savedgame.aSSDs;
if (typeof savedgame.aCPUcost !== "undefined") aCPUcost = savedgame.aCPUcost;
if (typeof savedgame.aCPUs !== "undefined") aCPUs = savedgame.aCPUs;
}

window.onload = function() {
loadgame();
updatescorepersecond();
document.getElementById("aCPUcost").innerHTML = aCPUcost;
document.getElementById("aCPUs").innerHTML = aCPUs;
document.getElementById("aSSDcost").innerHTML = aSSDcost;
document.getElementById("aSSDs").innerHTML = aSSDs;
document.getElementById("aGPUcost").innerHTML = aGPUcost;
document.getElementById("aGPUs").innerHTML = aGPUs;
document.getElementById("aRAMcost").innerHTML = aRAMcost;
document.getElementById("aRAMs").innerHTML = aRAMs;
document.getElementById("amotherboardcost").innerHTML = amotherboardcost;
document.getElementById("amotherboards").innerHTML = amotherboards;
document.getElementById("opCPUcost").innerHTML = opCPUcost;
document.getElementById("opCPUs").innerHTML = opCPUs;
document.getElementById("opSSDcost").innerHTML = opSSDcost;
document.getElementById("opSSDs").innerHTML = opSSDs;
document.getElementById("opGPUcost").innerHTML = opGPUcost;
document.getElementById("opGPUs").innerHTML = opGPUs;
document.getElementById("opRAMcost").innerHTML = opRAMcost;
document.getElementById("opRAMs").innerHTML = opRAMs;
document.getElementById("opmotherboardcost").innerHTML = opmotherboardcost;
document.getElementById("opmotherboards").innerHTML = opmotherboards;
document.getElementById("ProCPUcost").innerHTML = ProCPUcost;
document.getElementById("ProCPUs").innerHTML = ProCPUs;
document.getElementById("ProSSDcost").innerHTML = ProSSDcost;
document.getElementById("ProSSDs").innerHTML = ProSSDs;
document.getElementById("ProGPUcost").innerHTML = ProGPUcost;
document.getElementById("ProGPUs").innerHTML = ProGPUs;
document.getElementById("ProRAMcost").innerHTML = ProRAMcost;
document.getElementById("ProRAMs").innerHTML = ProRAMs;
document.getElementById("Promotherboardcost").innerHTML = Promotherboardcost;
document.getElementById("Promotherboards").innerHTML = Promotherboards;
document.getElementById("advancedCPUcost").innerHTML = advancedCPUcost;
document.getElementById("advancedCPUs").innerHTML = advancedCPUs;
document.getElementById("advancedSSDcost").innerHTML = advancedSSDcost;
document.getElementById("advancedSSDs").innerHTML = advancedSSDs;
document.getElementById("advancedGPUcost").innerHTML = advancedGPUcost;
document.getElementById("advancedGPUs").innerHTML = advancedGPUs;
document.getElementById("advancedRAMcost").innerHTML = advancedRAMcost;
document.getElementById("advancedRAMs").innerHTML = advancedRAMs;
document.getElementById("advancedmotherboardcost").innerHTML = advancedmotherboardcost;
document.getElementById("advancedmotherboards").innerHTML = advancedmotherboards;
document.getElementById("normalCPUcost").innerHTML = normalCPUcost;
document.getElementById("normalCPUs").innerHTML = normalCPUs;
document.getElementById("normalSSDcost").innerHTML = normalSSDcost;
document.getElementById("normalSSDs").innerHTML = normalSSDs;
document.getElementById("normalGPUcost").innerHTML = normalGPUcost;
document.getElementById("normalGPUs").innerHTML = normalGPUs;
document.getElementById("normalRAMcost").innerHTML = normalRAMcost;
document.getElementById("normalRAMs").innerHTML = normalRAMs;
document.getElementById("normalmotherboardcost").innerHTML = normalmotherboardcost;
document.getElementById("normalmotherboards").innerHTML = normalmotherboards
document.getElementById("CPUcost").innerHTML = CPUcost;
document.getElementById("CPUs").innerHTML = CPUs
document.getElementById("SSDcost").innerHTML = SSDcost;
document.getElementById("SSDs").innerHTML = SSDs;
document.getElementById("GPUcost").innerHTML = GPUcost;
document.getElementById("GPUs").innerHTML = GPUs
document.getElementById("gbRAMcost").innerHTML = gbRAMcost;
document.getElementById("gbRAMs").innerHTML = gbRAMs;
document.getElementById("basicmotherboardcost").innerHTML = basicmotherboardcost;
document.getElementById("basicmotherboards").innerHTML = basicmotherboards;
document.getElementById("score").innerHTML = score;
};

function savegame () {
var gamesave = {
score: score,
clickingpower: clickingpower,
basicmotherboardcost: basicmotherboardcost,
basicmotherboards: basicmotherboards,
gbRAMcost: gbRAMcost,
gbRAMs: gbRAMs,
GPUcost: GPUcost,
GPUs: GPUs,
SSDcost:SSDcost,
SSDs: SSDs,
CPUcost: CPUcost,
CPUs: CPUs,
normalmotherboardcost: normalmotherboardcost,
normalmotherboards: normalmotherboards,
normalRAMcost: normalRAMcost,
normalRAMs: normalRAMs,
normalGPUcost: normalGPUcost,
normalGPUs: normalGPUs,
normalSSDcost: normalSSDcost,
normalSSDs: normalSSDs,
normalCPUcost: normalCPUcost,
normalCPUs: normalCPUs,
advancedmotherboardcost: advancedmotherboardcost,
advancedmotherboards: advancedmotherboards,
advancedRAMcost: advancedRAMcost,
advancedRAMs: advancedRAMs,
advancedGPUcost: advancedGPUcost,
advancedGPUs: advancedGPUs,
advancedSSDcost: advancedSSDcost,
advancedSSDs: advancedSSDs,
advancedCPUcost:advancedCPUcost,
advancedCPUs: advancedCPUs,
Promotherboardcost: Promotherboardcost,
Promotherboards: Promotherboards,
ProRAMcost: ProRAMcost,
ProRAMs: ProRAMs,
ProGPUcost: ProGPUcost,
ProGPUs: ProGPUs,
ProSSDcost: ProSSDcost,
ProSSDs: ProSSDs,
ProCPUcost: ProCPUcost,
ProCPUs: ProCPUs,
opmotherboardcost: opmotherboardcost,
opmotherboards: opmotherboards,
opRAMcost: opRAMcost,
opGPUcost: opGPUcost,
opGPUs: opGPUs,
opSSDcost: opSSDcost,
opSSDs: opSSDs,
opCPUcost: opCPUcost,
opCPUs: opCPUs,
amotherboardcost: amotherboardcost,
amotherboards: amotherboards,
aCPUcost: aCPUcost,
aCPUs: aCPUs,
aRAMcost: aRAMcost,
aRAMs: aRAMs,
aSSDcost: aSSDcost,
aSSDs: aSSDs,
aGPUcost: aGPUcost,
aGPUs: aGPUs

};
localStorage.setItem("gamesave",JSON.stringify(gamesave));
}





function updatescorepersecond() {
scorepersecond = basicmotherboards + gbRAMs * 5 + GPUs * 10 + SSDs * 50 + CPUs * 75 + 
normalmotherboards * 100 + normalRAMs * 250 + normalGPUs * 500 + normalSSDs * 1000 + normalCPUs * 2500 + 
advancedmotherboards * 5000 + advancedRAMs * 7500 + advancedGPUs * 10000 + advancedSSDs * 25000 + advancedCPUs * 50000+
Promotherboards * 75000 + ProRAMs * 100000 + ProGPUs * 250000 + ProSSDs * 500000 + ProCPUs * 750000 +
opmotherboards * 1000000 + opRAMs * 2500000 + opGPUs * 5000000 + opSSDs * 7500000 + opCPUs * 10000000 +
amotherboards * 15000000 + aRAMs * 25000000 + aGPUs * 50000000 + aSSDs * 75000000 + aCPUs * 150000000;
document.getElementById("scorepersecond").innerHTML = scorepersecond;
}


setInterval(function() {

score = score + basicmotherboards;
score = score + gbRAMs * 5;
score = score + GPUs * 10;
score = score + SSDs * 50;
score = score + CPUs * 75;

score = score + normalmotherboards * 100;
score = score + normalRAMs * 250;
score = score + normalGPUs * 500;
score = score + normalSSDs * 1000;
score = score + normalCPUs * 2500;

score = score + advancedmotherboards * 5000;
score = score + advancedRAMs * 7500;
score = score + advancedGPUs * 10000;
score = score + advancedSSDs * 25000;
score = score + advancedCPUs * 50000;

score = score + Promotherboards * 75000;
score = score + ProRAMs * 100000;
score = score + ProGPUs * 250000;
score = score + ProSSDs * 500000;
Score = score + ProCPUs * 750000;

score = score + opmotherboards * 1000000;
score = score + opRAMs * 2500000;
score = score + opGPUs * 5000000;
score = score + opSSDs * 7500000;
score = score + opCPUs * 10000000;

score = score + amotherboards * 15000000;
score = score + aRAMs * 25000000;
score = score + aGPUs * 50000000;
score = score + aSSDs * 75000000;
score = score + aCPUs * 100000000;

document.getElementById("score").innerHTML = score;

}, 1000); // 1000ms = 1 second 

setInterval (function() {
savegame();
}, 30000); // 30000ms = 30 seconds

       // Function to trigger a mouse click event
       function triggerClick(x, y) {
        var event = new MouseEvent('click', {
            clientX: x,
            clientY: y,
            button: 0,
            buttons: 1
        });
        document.elementFromPoint(x, y).dispatchEvent(event);
    }

    // Variable to keep track of auto-clicking status
    let isAutoClicking = false;

    // Function to continuously follow the mouse pointer and trigger clicks
    function followMouseAndClick() {
        document.addEventListener('mousemove', function(event) {
            var mouseX = event.clientX;
            var mouseY = event.clientY;

            if (isAutoClicking) {
                triggerClick(mouseX, mouseY);
            }
        });
    }

    // Function to toggle auto-clicking when the "C" key is pressed
    function toggleAutoClick(event) {
        if (event.key === 'm' || event.key === 'm') {
            isAutoClicking = !isAutoClicking;
        }
    }

    // Call the followMouseAndClick function to start auto-clicking
    followMouseAndClick();

    // Listen for keydown events on the document to toggle auto-clicking
    document.addEventListener('keydown', toggleAutoClick);